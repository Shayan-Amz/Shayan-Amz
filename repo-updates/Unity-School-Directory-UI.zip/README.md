# School Directory UI (Unity)

[![Unity](https://img.shields.io/badge/Unity-6000.0.41f1-000000?logo=unity&logoColor=white)](https://unity.com/releases/editor/whats-new/6000.0.41)
[![Render pipeline](https://img.shields.io/badge/URP-2D%20Renderer-5c2d91)](https://docs.unity3d.com/Packages/com.unity.render-pipelines.universal@17.0/manual/index.html)
[![Language](https://img.shields.io/badge/C%23-uGUI%20%2B%20TextMeshPro-239120)](Assets/UIManager.cs)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

A compact, data-driven directory interface built with Unity's uGUI stack. The
application presents two tabs — **Students** and **Teachers** — each backed by
an in-memory collection that can be **searched as you type** and **sorted** by
name, age or grade. Rows are rendered from prefabs into a scrollable list, and
all interaction is wired through serialized `UnityEvent`s rather than
hard-coded lookups.

The project was written as a first, self-contained exercise in Unity's UI
tool-chain: canvas scaling, layout groups, prefab instantiation, TextMeshPro,
the new Input System and LINQ-based view logic in C#.

## Features

| Area | What is implemented |
|---|---|
| Tabbed navigation | Two panels toggled by header buttons; the active tab is highlighted by colour and a sliding underline indicator that is re-parented under the selected button |
| Prefab-based rows | `StudentListItemPrefab` / `TeacherListItemPrefab` are instantiated per record into a `VerticalLayoutGroup` + `ContentSizeFitter` inside a `ScrollRect` |
| Live search | `TMP_InputField.onValueChanged` filters the list on every keystroke (case-insensitive substring match on the name) |
| Sorting | Name (ascending), age (descending) and, for students, grade (descending) via LINQ `OrderBy` / `OrderByDescending` |
| Responsive canvas | Screen-Space-Camera canvas with `CanvasScaler` in *Scale With Screen Size* mode (reference 1920 × 1080, match width) |
| Input | Unity Input System: the `EventSystem` uses `InputSystemUIInputModule` with the package's default UI actions, and `InputSystem_Actions.inputactions` is registered as the project-wide actions asset |

## How it works

```mermaid
flowchart LR
    B["uGUI Buttons and TMP_InputField"] -- "UnityEvent (serialized in the scene)" --> M["UIManager (MonoBehaviour)"]
    M -- "LINQ Where / OrderBy" --> D[("In-memory List of Student / Teacher")]
    D --> M
    M -- "Instantiate one prefab per row" --> V["Scroll View / Content"]
```

### Scripts

| File | Role |
|---|---|
| [`Assets/Students.cs`](Assets/Students.cs) | `[Serializable] Student { name, age, grade }` — plain data class |
| [`Assets/Teachers.cs`](Assets/Teachers.cs) | `[Serializable] Teacher { name, age }` — plain data class |
| [`Assets/UIManager.cs`](Assets/UIManager.cs) | Single presenter: seeds sample data in `Start()`, switches tabs, populates the lists, and exposes the public sort/filter methods that the scene binds to |

### Scene wiring (`Assets/Scenes/SampleScene.unity`)

Every interaction is a persistent `UnityEvent` call on the `UIManagerObject`;
no component is located by name or tag at runtime.

| UI element | Event | `UIManager` method |
|---|---|---|
| Header button **Students** | `onClick` | `ShowStudentsTab()` |
| Header button **Teachers** | `onClick` | `ShowTeachersTab()` |
| StudentsPanel › *Sort By Name* / *Age* / *Grade* | `onClick` | `SortStudentsByName()` / `SortStudentsByAge()` / `SortStudentsByGrade()` |
| StudentsPanel › search field | `onValueChanged` | `FilterStudentList()` |
| TeachersPanel › *Sort By Name* / *Age* | `onClick` | `SortTeachersByName()` / `SortTeachersByAge()` |
| TeachersPanel › search field | `onValueChanged` | `FilterTeacherList()` |

### Row-prefab contract

`UIManager` fills a row by looking up child objects by name, so a prefab must
expose the following `TMP_Text` children:

| Prefab | Required children |
|---|---|
| `StudentListItemPrefab` | `NameText`, `AgeText`, `GradeText` |
| `TeacherListItemPrefab` | `NameText`, `AgeText` |

Refreshing a list destroys the current rows and instantiates a fresh set
(`PopulateStudentList` / `PopulateTeacherList`), which keeps the presenter
stateless with respect to the view.

## Getting started

1. Install **Unity 6 (6000.0.41f1)** through Unity Hub — any 6000.0.x
   release should open the project without an upgrade prompt.
2. Clone the repository and add the folder in Unity Hub (*Add → Add project
   from disk*). The first import generates the `Library/` folder and takes a
   couple of minutes.
3. Open `Assets/Scenes/SampleScene.unity` and press **Play**.

The project has no external dependencies beyond the packages listed in
[`Packages/manifest.json`](Packages/manifest.json) (Universal RP 17.0.4,
Input System 1.13.1, uGUI 2.0.0, TextMeshPro via uGUI, 2D feature set).
`.vsconfig` requests the *Game development with Unity* workload if you open
the solution in Visual Studio.

## Repository layout

```
Assets/
├── Scenes/SampleScene.unity        # the whole UI (canvas, panels, buttons, wiring)
├── Settings/                       # URP 2D renderer and pipeline assets
├── StudentListItemPrefab.prefab    # row prefab: NameText / AgeText / GradeText
├── TeacherListItemPrefab.prefab    # row prefab: NameText / AgeText
├── Students.cs · Teachers.cs       # data classes
├── UIManager.cs                    # presenter
├── InputSystem_Actions.inputactions
└── TextMesh Pro/                   # TMP essential resources (fonts, shaders)
Packages/                           # manifest + lock file
ProjectSettings/                    # project, URP and Input System settings
```

## Design notes and known limitations

The project deliberately keeps everything in one presenter so that the data
flow is easy to follow. The following points are the natural next steps, and
are documented here rather than hidden:

- **Data source.** Records are seeded in `InitializeData()`. A real directory
  would load them from a `ScriptableObject`, JSON (`JsonUtility`) or a web
  service, and the presenter would take an `IReadOnlyList<T>` instead of
  owning the lists.
- **Search semantics.** Matching uses `ToLower().Contains(...)`, which is
  culture-sensitive; `string.Contains(value, StringComparison.OrdinalIgnoreCase)`
  is the more robust choice.
- **Filter state across tabs.** Switching tabs repopulates the full list but
  does not clear the other tab's search field, so a stale query can remain
  visible in the input box.
- **Duplication.** `PopulateStudentList` and `PopulateTeacherList` (and their
  sort/filter helpers) are structurally identical; a generic
  `PopulateList<T>(IEnumerable<T>, Action<GameObject, T>)` would remove the
  repetition and make adding a third entity type trivial.
- **Allocation.** Rows are destroyed and re-instantiated on every refresh.
  Object pooling (or a virtualised list) would be needed for large datasets.
- **Testing.** The presenter mixes view logic and `UnityEngine` calls; moving
  the filter/sort logic into a plain C# class would allow Edit-Mode NUnit
  tests without a scene.

## Third-party assets

- **TextMesh Pro essential resources** (`Assets/TextMesh Pro/`), imported
  through *Window → TextMeshPro → Import TMP Essential Resources*: Liberation
  Sans (SIL Open Font License 1.1, see `Fonts/LiberationSans - OFL.txt`) and
  the EmojiOne sample sprites (see `Sprites/EmojiOne Attribution.txt`).
- Unity packages as listed in `Packages/manifest.json`, under the Unity
  Companion License.

## License

The project's own code and assets are released under the [MIT License](LICENSE).
