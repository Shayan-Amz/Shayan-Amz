# 🏠 Real-Estate Listing Manager (املاک من)

[![HTML5](https://img.shields.io/badge/HTML5-semantic-E34F26?logo=html5&logoColor=white)](https://developer.mozilla.org/docs/Web/HTML)
[![CSS3](https://img.shields.io/badge/CSS3-responsive%20%C2%B7%20RTL-1572B6?logo=css&logoColor=white)](https://developer.mozilla.org/docs/Web/CSS)
[![JavaScript](https://img.shields.io/badge/JavaScript-ES2020%20vanilla-F7DF1E?logo=javascript&logoColor=black)](https://developer.mozilla.org/docs/Web/JavaScript)
[![Dependencies](https://img.shields.io/badge/dependencies-none-success)](#tech-stack)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

A **dependency-free, offline-first single-page application** for managing real-estate listings, built
for the Iranian market: fully **right-to-left Persian UI**, three local deal types (sale, deposit + monthly
rent, full-deposit lease), and prices in toman. Everything — data, filtering, sorting — happens in the
browser; listings persist in `localStorage`, so the app works without a server or network connection.

The whole application is a single `index.html` (≈ 570 lines: markup, styles and logic). Open it and it runs.

---

## Table of Contents

- [Features](#features)
- [Demo](#demo)
- [How it works](#how-it-works)
- [Data model](#data-model)
- [Tech stack](#tech-stack)
- [Run locally](#run-locally)
- [Design decisions & limitations](#design-decisions--limitations)
- [Roadmap](#roadmap)
- [License](#license)

---

## Features

| Area | Details |
| :--- | :--- |
| **Listing form** | Referrer, city, usage (residential / commercial / office / land), area, free-text description |
| **Three deal types** | *Sale* (total price) · *Deposit + rent* (deposit and monthly rent) · *Full-deposit lease* (deposit only). The form shows only the price fields relevant to the selected type and toggles `required` accordingly |
| **Live price preview** | Amounts are echoed with thousands separators as you type (`5,000,000,000 تومان`) |
| **Filtering** | By usage, by deal type, and by price range — sale listings are compared on price, rental listings on deposit |
| **Sorting** | Newest first · cheapest · most expensive · largest area · smallest area |
| **Persistence** | Listings are stored in `localStorage` under one key and restored on load; two sample listings seed an empty store |
| **Safe deletion** | Confirmation modal before a listing is removed |
| **Mobile-first UI** | Sticky header with live listing count, bottom tab bar (list / add), card layout, subtle fade-in animations, custom RTL input icons |
| **Security hygiene** | All user-provided text is HTML-escaped before rendering, so a description such as `<img onerror=…>` is displayed as text |

---

## Demo

Open **`index.html`** in any modern browser — no build step, no server required.

<details>
<summary>What you will see</summary>

1. **Listings tab** — filter bar (usage · deal type · min/max price · sort) above a list of cards. Each card shows
   the deal-type tag, usage icon, city, area, referrer, the price block and the description.
2. **Add tab** — the listing form. Switching the deal type toggles between *price*, *deposit + rent* and *deposit*
   fields; submitting returns to the list with the new listing on top.
3. **Delete** — the 🗑️ button opens a confirmation dialog; confirming removes the card and updates storage.

</details>

---

## How it works

```text
┌──────────────────────────────────────────────────────────────────────┐
│ index.html                                                           │
│                                                                      │
│  <style>   mobile-first layout, RTL-aware form controls, cards,      │
│            modal, bottom navigation                                  │
│                                                                      │
│  <body>    #list-view  (filters + #properties-container)             │
│            #add-view   (#add-form with deal-type switcher)           │
│            #delete-modal, <nav> tab bar                              │
│                                                                      │
│  <script>  properties[]  ⇄  localStorage["realEstatePropertiesOffline"]
│            renderProperties()  = filter → sort → build cards → paint  │
│            setDealType()       = toggle price fields + required flags │
│            submit handler      = validate → unshift → save → re-render│
│            show/confirm/cancelDelete()                                │
│            formatMoney(), escapeHtml()                                │
└──────────────────────────────────────────────────────────────────────┘
```

`renderProperties()` is the single rendering path: it reads the current filter and sort controls,
derives the visible subset from the in-memory `properties` array, builds all cards as strings and
paints them in one `innerHTML` assignment. Every mutation (add / delete) writes to `localStorage`
and calls it again, which keeps UI and storage trivially consistent.

---

## Data model

Each listing is a plain object:

```jsonc
{
  "id": 1718000000000,            // Date.now() at creation, also used for "newest" sorting
  "referrer": "احمدی",            // who introduced the property
  "city": "تهران",
  "usage": "مسکونی",              // مسکونی | تجاری | اداری | زمین/کلنگی
  "area": 120,                    // m²
  "dealType": "فروش",             // فروش | رهن و اجاره | رهن کامل
  "price": 5000000000,            // sale only (toman)
  "deposit": 300000000,           // rental types only
  "rent": 15000000,               // "رهن و اجاره" only
  "description": "آپارتمان نوساز، کلید نخورده",
  "date": "2026-04-11T09:30:00.000Z"
}
```

---

## Tech stack

- **HTML5 / CSS3** — flexbox & grid layout, CSS custom transitions, `dir="rtl"` document with icon
  padding adjusted for right-to-left inputs, system font stack (no web-font download)
- **Vanilla JavaScript (ES2020)** — no framework, no bundler, no external requests
- **Web Storage API** — `localStorage` persistence

---

## Run locally

```bash
git clone https://github.com/Shayan-Amz/RealStateHTML.git
cd RealStateHTML
# then simply open index.html, or serve it:
python -m http.server 8000     # → http://localhost:8000
```

Works in current Chrome, Firefox, Safari and Edge (desktop and mobile).

---

## Design decisions & limitations

- **Single file by design.** The goal was a tool that can be e-mailed or dropped on a phone and used
  offline by a non-technical agent. Splitting into modules would add a build step without a functional gain
  at this size.
- **Client-side only.** Data lives in the browser profile that created it; there is no sync between devices,
  no multi-user access and no backup beyond the browser. A backend (or export/import) is the natural next step.
- **Price comparison across deal types.** Filtering and sorting compare *price* for sales and *deposit* for
  rentals — a pragmatic choice that keeps a single price range control useful for mixed lists.
- **Persian numerals.** Amounts are formatted with Latin digits and comma separators for unambiguous input; a
  Persian-digit display option is on the roadmap.

---

## Roadmap

- [ ] JSON export / import for backup and transfer between devices
- [ ] Edit an existing listing (currently add / delete only)
- [ ] Optional photo attachment per listing (stored as data URLs or IndexedDB)
- [ ] Persian-digit formatting toggle and amount-in-words helper (e.g. «۵ میلیارد تومان»)
- [ ] Split into `index.html` / `style.css` / `app.js` once a second page is needed

---

## License

Released under the [MIT License](LICENSE).
