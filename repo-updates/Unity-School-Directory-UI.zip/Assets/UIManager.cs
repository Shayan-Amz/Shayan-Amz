using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class UIManager : MonoBehaviour
{
    [Header("Tab Panels and Buttons")]
    public GameObject studentsPanel;
    public GameObject teachersPanel;
    public Button studentTabButton;
    public Button teacherTabButton;
    public GameObject underlineIndicator;

    [Header("Tab Colors")]
    public Color activeTabColor = Color.cyan;
    public Color inactiveTabColor = Color.white;

    [Header("Student UI Elements")]
    public TMP_InputField studentSearchInput;
    public Transform studentContentPanel;
    public GameObject studentListItemPrefab;

    [Header("Teacher UI Elements")]
    public TMP_InputField teacherSearchInput;
    public Transform teacherContentPanel;
    public GameObject teacherListItemPrefab;

    private List<Student> students = new List<Student>();
    private List<Teacher> teachers = new List<Teacher>();

    void Start()
    {
        InitializeData();
        ShowStudentsTab();
    }

    void InitializeData()
    {
        students.Add(new Student("Ali", 10, 85));
        students.Add(new Student("Arman", 12, 92));
        students.Add(new Student("Fateme", 11, 78));
        teachers.Add(new Teacher("Mr. Rezaei", 45));
        teachers.Add(new Teacher("Ms. Maryam", 38));
        teachers.Add(new Teacher("Mrs. Nazanin", 52));
    }

    public void ShowStudentsTab()
    {
        studentsPanel.SetActive(true);
        teachersPanel.SetActive(false);
        PopulateStudentList(students);

        SetButtonColor(studentTabButton, activeTabColor);
        SetButtonColor(teacherTabButton, inactiveTabColor);

        underlineIndicator.transform.SetParent(studentTabButton.transform, false);
        underlineIndicator.GetComponent<RectTransform>().anchoredPosition = new Vector2(0, -35);
    }

    public void ShowTeachersTab()
    {
        studentsPanel.SetActive(false);
        teachersPanel.SetActive(true);
        PopulateTeacherList(teachers);

        SetButtonColor(studentTabButton, inactiveTabColor);
        SetButtonColor(teacherTabButton, activeTabColor);

        underlineIndicator.transform.SetParent(teacherTabButton.transform, false);
        underlineIndicator.GetComponent<RectTransform>().anchoredPosition = new Vector2(0, -35);
    }

    #region Helper Methods and Filtering
    void SetButtonColor(Button button, Color targetColor)
    {
        var colors = button.colors;
        colors.normalColor = targetColor;
        colors.selectedColor = targetColor;
        button.colors = colors;
    }

    void PopulateStudentList(List<Student> studentList)
    {
        foreach (Transform child in studentContentPanel) Destroy(child.gameObject);
        foreach (var student in studentList)
        {
            GameObject item = Instantiate(studentListItemPrefab, studentContentPanel);
            item.transform.Find("NameText").GetComponent<TMP_Text>().text = "Name: " + student.name;
            item.transform.Find("AgeText").GetComponent<TMP_Text>().text = "Age: " + student.age.ToString();
            item.transform.Find("GradeText").GetComponent<TMP_Text>().text = "Grade: " + student.grade.ToString();
        }
    }

    void PopulateTeacherList(List<Teacher> teacherList)
    {
        foreach (Transform child in teacherContentPanel) Destroy(child.gameObject);
        foreach (var teacher in teacherList)
        {
            GameObject item = Instantiate(teacherListItemPrefab, teacherContentPanel);
            item.transform.Find("NameText").GetComponent<TMP_Text>().text = "Name: " + teacher.name;
            item.transform.Find("AgeText").GetComponent<TMP_Text>().text = "Age: " + teacher.age.ToString();
        }
    }

    public void SortStudentsByName() => PopulateStudentList(students.OrderBy(s => s.name).ToList());
    public void SortStudentsByAge() => PopulateStudentList(students.OrderByDescending(s => s.age).ToList());
    public void SortStudentsByGrade() => PopulateStudentList(students.OrderByDescending(s => s.grade).ToList());
    public void FilterStudentList()
    {
        var filteredList = students.Where(s => s.name.ToLower().Contains(studentSearchInput.text.ToLower())).ToList();
        PopulateStudentList(filteredList);
    }

    public void SortTeachersByName() => PopulateTeacherList(teachers.OrderBy(t => t.name).ToList());
    public void SortTeachersByAge() => PopulateTeacherList(teachers.OrderByDescending(t => t.age).ToList());
    public void FilterTeacherList()
    {
        var filteredList = teachers.Where(t => t.name.ToLower().Contains(teacherSearchInput.text.ToLower())).ToList();
        PopulateTeacherList(filteredList);
    }
    #endregion
}